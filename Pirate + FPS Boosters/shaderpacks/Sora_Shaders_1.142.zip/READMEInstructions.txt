You can extract the shaders folder into another folder and put that folder into shaderpacks to make changing skyboxes easier. 
Rename textures in Sora_Shaders_1.141>shaders>textures to skyboxes.png to match the skybox to the color style. The alternative skyboxes are named accordingly

